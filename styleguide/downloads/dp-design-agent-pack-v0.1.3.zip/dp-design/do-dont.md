# DP Design · 正反例速查

## 色彩与组件

| ✅ | ❌ |
|----|----|
| 主按钮用 `--dp-color-action` | 业务站写死另一套蓝 / 青霓虹 |
| Product 卡片边框 + 轻或无阴影 | 重 glow、多层彩色阴影 |
| 一页一个 Primary | 一排多个实心主按钮 |
| Focus = Action 边 + 3px 环 | 去掉焦点样式 |
| Action 实心底用 `--dp-text-on-primary` | 深蓝底叠黑色字母（Avatar/Logo） |
| Avatar 默认浅底 + Action 字，或实心底 + 浅色字 | 实心蓝底 + Text 1 / 黑字 |

## 顶栏与工具钮

| ✅ | ❌ |
|----|----|
| 同排「会话 / 智能体」与「对话 / 工作流」同为 14px · Text 1 | 前者 text-xs 浅灰，后者正常主字 |
| 主题切换用 `time-moon` / `time-sun` | 「深」「浅」单字按钮 |
| 下载用 `action-download` + 可选文案 | 仅灰字「下载」、无图标且过浅 |

## 文案与语言（`zh`）

| ✅ | ❌ |
|----|----|
| 提交任务后查看结合能曲线 | 提交 Job 后查看 Energy 曲线 |
| 未能读取数据。请确认后重试。 | 错误！！数据异常 |
| 按钮「导出结果」 | 无语境「确定」 |

## 空态 / 反馈

| ✅ | ❌ |
|----|----|
| 空态线型图标 48–64 → 标题 → 说明 → 一主按钮 | 只有一句「暂无数据」无行动 |
| 空态用图标库（inbox / search / lock…） | 引用 `illustrations/dp-illust-*.svg` 存档图 |
| 删除用 Modal 确认 | 删除仅 Toast |
| Toast 短结果 | Toast 写长篇说明 |

## 场景

| ✅ | ❌ |
|----|----|
| Product：侧栏主导、密度高、克制 | Product 大面积紫蓝渐变 |
| Showcase：顶栏 + 通栏、可营销辅色 | Showcase 控件也用霓虹主色 |
| 登记业务例外控件 | 静默 fork 全套色板 |
