---
name: dp-design
description: >-
  Applies DP Design (Bohrium Baseline) when restyling or building frontend UI for
  DP/Bohrium-aligned products. Use when aligning colors, typography, layout,
  components, empty/result states, copy, i18n (zh/en), or tokens to the DP Design
  system; when the user mentions DP Design, Bohrium 视觉, 设计规范, 改皮, or
  design-system/dp-bohrium.
---

# DP Design（Cursor 适配）

本文件供 **Cursor** 发现与加载。完整、工具无关的指令见同目录 **[AGENT.md](AGENT.md)**。

**必须先阅读并遵循 [AGENT.md](AGENT.md)**，以及 [tokens-cheatsheet.md](tokens-cheatsheet.md)、[do-dont.md](do-dont.md)。

## Cursor 安装

将本目录放到：

```text
your-project/.cursor/skills/dp-design/
```

对话中说明「按 DP Design 改」或点名 `dp-design`。其他编辑器见 [INSTALL.md](INSTALL.md)。
