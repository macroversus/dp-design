# DP Design Agent Pack · 安装说明（任意 AI 编程工具）

版本：与指南站一致时见设计系统 `docs/CHANGELOG.md`。  
包内**主指令**始终是 **`AGENT.md`**（工具无关）。其余文件为速查或某工具的薄适配。

## 通用步骤（推荐）

1. 从指南站「介绍」页下载 zip，解压得到 `dp-design/`。  
2. 放入目标项目（路径任选其一，团队统一即可）：

```text
your-project/docs/dp-design/     # 推荐：与编辑器解耦
# 或
your-project/.ai/dp-design/
# 或
your-project/design/dp-design/
```

3. 按下方矩阵，让你的 AI 工具**加载或引用** `AGENT.md`。  
4. 改前端时说明：「按 DP Design / docs/dp-design/AGENT.md 执行」。  
5. 样式细节打开指南站对照。

---

## 各工具怎么接

| 工具 | 建议做法 |
|------|----------|
| **任意 / 未知工具** | 把 `AGENT.md` 全文或路径写进该工具的「自定义指令 / 项目规则 / System prompt」；或每次对话 `@` / 粘贴 `AGENT.md` |
| **Cursor** | 另拷一份到 `.cursor/skills/dp-design/`（保留 `SKILL.md`）；或 Rules 中写「前端改动遵循 docs/dp-design/AGENT.md」 |
| **Claude Code** | 项目根 `CLAUDE.md` 增加一节：前端 UI 必须遵循 `docs/dp-design/AGENT.md`；重要约束可摘抄硬约束列表 |
| **GitHub Copilot** | `.github/copilot-instructions.md`（或仓库 Custom instructions）中引用同上路径 |
| **Windsurf** | 项目规则 / `.windsurfrules` 中指向 `AGENT.md` |
| **Continue** | `.continue/rules` 或 config 中加入对 `AGENT.md` 的规则引用 |
| **Codex / 其他读 AGENTS.md 的工具** | 将 [templates/AGENTS.snippet.md](templates/AGENTS.snippet.md) 合并进项目根 `AGENTS.md` |
| **VS Code + 任意 Chat** | 用「项目说明」附件或工作区推荐文件加入 `AGENT.md` |

---

## 包内文件

| 文件 | 作用 |
|------|------|
| `AGENT.md` | **主指令**（所有工具共用） |
| `tokens-cheatsheet.md` | Token / 圆角 / 字体速查 |
| `do-dont.md` | 正反例 |
| `SKILL.md` | 仅 Cursor 发现用（指向 AGENT.md） |
| `templates/AGENTS.snippet.md` | 合并进根目录 AGENTS.md 的片段 |
| `INSTALL.md` / `README.md` | 给人看的安装与说明 |

**不含**特定站点落地顺序；任意对齐 DP Design 的产品均可使用。
